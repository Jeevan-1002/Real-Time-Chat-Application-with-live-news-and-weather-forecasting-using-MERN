import React from 'react'
import ReactDOM from 'react-dom/client'
import Appw from './weather'
//import './weather.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Appw />
  </React.StrictMode>,
)
