import React from 'react';
import { Link } from 'react-router-dom';
import MessageContainer from "../../components/messages/MessageContainer";
import Sidebar from "../../components/sidebar/Sidebar";
import SignUP from "../signup/SignUp";

const Adminhome = () => {
    return (
        <div className='flex sm:h-[450px] md:h-[550px] rounded-lg overflow-hidden bg-gray-400 bg-clip-padding backdrop-filter backdrop-blur-lg bg-opacity-0'>
            <Sidebar />
            <Link to='/admin/createUser' className='text-sm  hover:underline hover:text-blue-600 mt-2 inline-block'> {/* Link to news page */}
                <button type='submit' className='btn btn-rectangle bg-sky-500 text-white w-26 h-6 outline-none padding:40px'>Add Users</button>

            </Link>

        </div>
    );
};

export default Adminhome;
