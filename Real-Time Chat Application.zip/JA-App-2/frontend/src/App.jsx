import { Navigate, Route, Routes } from "react-router-dom";
import "./App.css";
import Home from "./pages/home/Home";
import Adminhome from "./pages/adminhome/Adminhome";
import Login from "./pages/login/Login";
import SignUp from "./pages/signup/SignUp";
import NewsPage from "./components/messages/news";
import Weatherpage from "./components/messages/weather";// Correct import path and component name
import { Toaster } from "react-hot-toast";
import { useAuthContext } from "./context/AuthContext";

function App() {
  const { authUser } = useAuthContext();
  console.log(authUser)
  return (
    <div className="p-4 h-screen flex items-center justify-center">
      <Routes>
        <Route path="/" element={authUser ? authUser?.admin ? <Adminhome /> : <Home /> : <Navigate to={"/login"} />} />
        <Route path="/login" element={authUser ? <Navigate to={authUser?.admin ? "/admin/dashboard" : "/"} /> : <Login />} />
        <Route path="/news" element={authUser ? <NewsPage /> : <Navigate to="/" />} /> {/* Correct component name */}
        <Route path="/weather" element={authUser ? <Weatherpage /> : <Navigate to="/" />} /> {/* Correct component name */}

        {/* admin routes */}
        <Route path="/admin/dashboard" element={authUser?.admin ? <Adminhome /> : <Navigate to={"/login"} />} />
        <Route path="/admin/createUser" element={authUser?.admin ? <SignUp /> : <Navigate to={"/login"} />} />
      </Routes>
      <Toaster />
    </div>
  );
}

export default App;
